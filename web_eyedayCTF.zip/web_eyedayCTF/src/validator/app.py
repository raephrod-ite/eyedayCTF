from flask import Flask, render_template, request
import requests
import re
from urllib.parse import urlparse

app = Flask(__name__)


def is_blocked(url):
    try:
        parsed = urlparse(url)
        host = parsed.hostname or ""
    except Exception:
        return True

    first_label = host.split(".")[0]
    return bool(re.fullmatch(r"sunctf-svc-[a-f0-9]+", first_label))


@app.route("/", methods=["GET", "POST"])
def index():

    result = None
    error = None

    if request.method == "POST":

        url = request.form.get("url", "")

        if is_blocked(url):
            error = "Blocked: target host is on the internal restricted list."

        else:

            try:
                response = requests.get(url, timeout=4)
                result = response.text[:5000]

            except Exception:
                error = "Unable to retrieve resource."

    return render_template(
        "index.html",
        result=result,
        error=error
    )


@app.route("/config.bak")
def config_backup():

    return """
##########################################
# Internal deployment configuration
##########################################

APP_ENV=production

PUBLIC_URL=http://validator:8000

TELEMETRY_URL=http://172.28.0.10:5001

LOG_LEVEL=INFO

# TODO
# Remove internal URLs before release.
""",200,{"Content-Type":"text/plain"}


if __name__ == "__main__":
    app.run(host="0.0.0.0",port=8000)