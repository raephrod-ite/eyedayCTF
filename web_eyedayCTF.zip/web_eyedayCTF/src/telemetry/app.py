from flask import Flask, send_from_directory
import os

app = Flask(__name__)


@app.route("/")
def home():
    return """
SunCTF Telemetry Service
Version: 0.9.7

Status: ONLINE

Available Services

GET /health
GET /metrics
"""


@app.route("/health")
def health():
    return """
Status: Healthy

Runtime: Python 3.12

Environment: Production
"""


@app.route("/metrics")
def metrics():
    return """
uptime_seconds 14528
requests_total 382
backup_jobs_total 12

Latest Backup:
backup_20260813

last_backup_directory=/backups/
"""


# -----------------------------
# Backups Root
# -----------------------------

@app.route("/backups/")
def backups():
    return """
Index of /backups/

config.json
runtime.log
notes.txt
backup_20260813/
"""


@app.route("/backups/config.json")
def config():
    return send_from_directory("backups", "config.json")


@app.route("/backups/runtime.log")
def runtime():
    return send_from_directory("backups", "runtime.log")


@app.route("/backups/notes.txt")
def notes():
    return send_from_directory("backups", "notes.txt")


# -----------------------------
# Backup Folder
# -----------------------------

@app.route("/backups/backup_20260813/")
def backup_folder():
    return """
Index of /backups/backup_20260813/

backup_manifest.txt
old.log
temp/
"""


@app.route("/backups/backup_20260813/backup_manifest.txt")
def manifest():
    return send_from_directory(
        os.path.join("backups", "backup_20260813"),
        "backup_manifest.txt"
    )


@app.route("/backups/backup_20260813/old.log")
def oldlog():
    return send_from_directory(
        os.path.join("backups", "backup_20260813"),
        "old.log"
    )


# -----------------------------
# Temp Folder
# -----------------------------

@app.route("/backups/backup_20260813/temp/")
def temp():
    return """
Index of /backups/backup_20260813/temp/

deployment_notes.txt
"""


@app.route("/backups/backup_20260813/temp/deployment_notes.txt")
def deployment_notes():
    return send_from_directory(
        os.path.join("backups", "backup_20260813", "temp"),
        "deployment_notes.txt"
    )


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001)